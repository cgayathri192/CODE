import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { AdminService } from '../admin.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-administrator',
  templateUrl: './add-administrator.component.html',
  styleUrls: ['./add-administrator.component.scss']
})
export class AddAdministratorComponent implements OnInit {
  addAdminstrator:any = FormGroup;
  empId:any;
  
  constructor(private formBuilder: FormBuilder,private ser:AdminService,private route:ActivatedRoute) { }
  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      if (params.get('id')) {
        this.empId = params.get('id');
      }
    });
     this.addAdminstrator = this.formBuilder.group({
      name: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      contactNumber: ['', [Validators.required, this.contactNumberValidator]],
      excption: [false],
      dashboardAndReports: [false],
      patients: [false],
    });
     if(this.empId){
      this.ser.get1Employees(this.empId)
     }
  }
  permissionCheckboxValidation(): boolean {
    const excptionChecked = this.addAdminstrator?.get('excption').value || false;
    const dashboardAndReportsChecked = this.addAdminstrator?.get('dashboardAndReports').value || false;
    return excptionChecked || dashboardAndReportsChecked;
  }
  contactNumberValidator(control: AbstractControl): ValidationErrors | null {
    const contactNumber: string = control.value;
    const isValid = /^\d{10}$/.test(contactNumber);
    return isValid ? null : { invalidContactNumber: true };
  }
  get f() {
    return this.addAdminstrator.controls;
  }
  onSubmit() {
    const admindata:any ={
      name :  this.addAdminstrator.value.name,
      lastName :  this.addAdminstrator.value.lastName,
      email : this.addAdminstrator.value.email,
      contactNumber : this.addAdminstrator.value.contactNumber,
      excption:this.addAdminstrator.value.excption,
      dashboardAndReports : this.addAdminstrator.value.dashboardAndReports,
      patients : this.addAdminstrator.value.patients,
      empId : this.addAdminstrator.value.empId
     }
   if (this.addAdminstrator.invalid || !this.permissionCheckboxValidation()) {
      return;
    }
    if(this.empId){
      admindata['adminId']= this.empId
    }
    this.ser.addAdmin(admindata).subscribe(
      (res) => {
        console.log('Administrator added successfully:', res);
        this.addAdminstrator.reset();
      },
      (error) => {
        console.error('Failed to add administrator:', error);
      }
    );
  }
  }

 


 

