import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';


@Component({
  selector: 'app-roles-and-permissions',
  templateUrl: './roles-and-permissions.component.html',
  styleUrls: ['./roles-and-permissions.component.scss']
})
export class RolesAndPermissionsComponent implements OnInit {
   patientList:any=[]
   emp:any
  constructor(private router:Router,private ser:AdminService) { }

  ngOnInit(): void {
    this.getdata()
  }
  getdata(){
    
  // const payload =   {
  //     "empId": "Admin_1675860303677",
  //     "firstName": "yrur",
  //     "lastName": "jhjhj",
  //     "email": "test@gnmail.com",
  //     "contactNo": "7676767878",
  //     "approvalStatus": "Approved",
  // }
    // this.ser.getEmployees(payload).subscribe((res:any)=>{
    //   console.log(res)
    //   this.patientList=res
    // })

    this.ser.get1Employees(this.emp).subscribe((res:any)=>{
      this.patientList=res
      // console.log(res[0].empId,'id')
    })
  }

}
