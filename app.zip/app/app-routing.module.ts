import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RolesAndPermissionsComponent } from './roles-and-permissions/roles-and-permissions.component';
import { AddAdministratorComponent } from './add-administrator/add-administrator.component';

const routes: Routes = [
  {
    path:'roles',
    component:RolesAndPermissionsComponent
  },
  {
    path:'add',
    component:AddAdministratorComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
